#include "unity.h"
#include "foo.h"

void setUp(void)
{
}

void tearDown(void)
{
}

// Create one passing and one failing assertion using TEST_ASSERT_TRUE.
void testTEST_ASSERT_TRUE (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_FALSE.
void testTEST_ASSERT_FALSE (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_EQUAL_INT8.
// Try it with negative decimal numbers, positive decimal numbers, and hexadecimal numbers.
void testTEST_ASSERT_EQUAL_INT8 (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_EQUAL_UINT8.
// Try it with negative decimal numbers, positive decimal numbers, and hexadecimal numbers.
void testTEST_ASSERT_EQUAL_UINT8 (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_EQUAL_HEX8.
// Try it with negative decimal numbers, positive decimal numbers, and hexadecimal numbers.
void testTEST_ASSERT_EQUAL_HEX8 (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_UINT_WITHIN.
void testTEST_ASSERT_UINT_WITHIN (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_BITS.
void testTEST_ASSERT_BITS (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_BITS_HIGH.
void testTEST_ASSERT_BITS_HIGH (void)
{

}

// Create one passing and one failing assertion using TEST_ASSERT_BIT_HIGH.
void testTEST_ASSERT_BIT_HIGH (void)
{

}

// Exhaustively test the squareNumber function located in foo.c.
// squareNumber takes an 8-bit unsigned integer as input, squares it, and then returns the squared value as a 16-bit unsigned integer.
void testsquareNumber (void)
{
	
}