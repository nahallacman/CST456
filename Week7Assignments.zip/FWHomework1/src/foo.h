#ifndef _FOO_H
#define _FOO_H

#include <stdint.h>

#endif // _FOO_H
