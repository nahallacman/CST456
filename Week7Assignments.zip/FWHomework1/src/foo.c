#include "foo.h"

uint16_t squareNumber (uint8_t numberToBeSquared)
{
	return ((uint16_t) numberToBeSquared * numberToBeSquared);
}
